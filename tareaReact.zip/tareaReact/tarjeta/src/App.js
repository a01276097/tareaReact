import './App.css';
import cheems from "./cheems.jpg"

function App() {
  return (
    <div className="tarjeta">
      <img src={cheems} className="elcheems" />
      <p className="nota">no tengo fotos mias :D</p>
      <p className="texto">Diego Samperio Avila</p>
      <p className="texto">a01276097@itesm.mx</p>
      <p className="texto">@a01276097 en github</p>
    </div>
  );
}

export default App;
